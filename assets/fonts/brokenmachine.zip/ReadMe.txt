----------------
IMPORTANT NOTES
----------------

Note that my font ( BrokenMachine) is free for personal use,
to use for commercial purpose you will need to donate me "$10/per user".

my paypal address: deheludin@gmail.com
Thank you for your donation, I really appriciate it.Hope you like my font. 

---------------------------------------
Terms & Conditions for commercial use :
---------------------------------------

1.My font cannot be redistributed for your owns benefit.
2.My font cannot be used for sex & alcohol content or any actions that not legal,please be respectful with my works.
3.Other than those 2 terms, feel free to use my font.

--------------------------
Copyright � 2017 , DeheL
--------------------------





